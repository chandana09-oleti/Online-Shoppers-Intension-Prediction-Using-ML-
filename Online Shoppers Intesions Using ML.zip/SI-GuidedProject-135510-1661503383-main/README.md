# SI-GuidedProject-135510-1661503383
Online Shoppers Intentions Using Machine Learning
https://drive.google.com/file/d/1Q-3vInO7K9fIT4-Wp4X6Iqah04WozFpr/view?usp=sharing 
demo vedio link
